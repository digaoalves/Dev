#import <UIKit/UIKit.h>
#import "CWIWidget.h"
#import "KonyCWIEnvironment.h"
#import "CustomButtonWidgetEventDelegate.h"

@interface CustomButtonWidget : UIControl<CWIWidget> 
{
	// The Kony environment class comprises a property model, 
	// which enables you to fetch data from the custom widget protocol and to send data between the application and custom widget protocol.
    KonyCWIEnvironment *konyEnviroment;
	
	// The Event delegate comprises events to be invoked for your custom widget.
    id <CustomButtonWidgetEventDelegate> buttonWidgetEventDelegate;

	// This is the property for our custom button widget
	NSString * text;
}

@property (nonatomic, retain) KonyCWIEnvironment *konyEnviroment;
@property (nonatomic, retain) id <CustomButtonWidgetEventDelegate> buttonWidgetEventDelegate;
@property (nonatomic,retain) NSString *text;

@end

