#import "CustomButtonWidget.h"

@implementation CustomButtonWidget

@synthesize konyEnviroment, buttonWidgetEventDelegate, text;

- (id)init
{
    NSLog(@"***** Entering into init *****");
	self = [super init];
    if (self) 
	{
		UIButton *button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
		NSLog(@"***** Created button widget *****");
		// position in the parent view and set the size of the button
		button.frame = CGRectMake(10, 20, 300, 50);
        [button setTitle:@"Custom Button" forState:UIControlStateNormal];
		[button addTarget:self action:@selector(buttonAction) forControlEvents:UIControlEventTouchUpInside];
		// add to a view
		[self addSubview:button];        
		NSLog(@"***** Added button widget to superView *****");
    }
	NSLog(@"***** Exiting out of init *****");
	return self;
}

-(void)buttonAction
{
	NSLog(@"***** Entering into buttonAction *****");
	[self.buttonWidgetEventDelegate onClickHandler];
	NSLog(@"***** Exiting out of buttonAction *****");
}

#pragma mark Custom Widget Protocols Methods

// Invoked by platform to initialize any object of the custom widget. Initializing the Kony Environment and Custom Widget instance.
- (id) initWithEventDelegate: (id) eventDelegate withKonyEnvironment:(id) env
{
    NSLog(@"***** Entering into initWithEventDelegatewithKonyEnvironment *****");
    self = [self init];
    self.konyEnviroment = env;
    self.buttonWidgetEventDelegate = eventDelegate;
    NSLog(@"***** Exiting out of initWithEventDelegatewithKonyEnvironment *****");
    return self;
}

// Fetch the preferred size(Height and width) for the widget. The CGSize parameter is the parent width and height of the widget.
- (CGSize) getPreferredSizeForGivenSize: (CGSize) givenSize
{
    NSLog(@"***** Entering into getPreferredSizeForGivenSize *****");
    CGSize preferredSize = givenSize;
    preferredSize.height = 44;
    NSLog(@"***** Exiting out of getPreferredSizeForGivenSize *****");
    return preferredSize;
}

// Set the position of the custom widget with respect to the parent widget. Provides x, y coordinates, height, and width for the custom widget with reference to the parent widget.
- (void) setWidgetViewFrame: (CGRect) frame
{
    NSLog(@"***** Entering into setWidgetViewFrame *****");
    NSLog(@"***** frame: %@ *****" ,NSStringFromCGRect(frame));
    self.frame = frame;
    NSLog(@"***** Exiting out of setWidgetViewFrame *****");
}

// Returns the view defined for the custom widget.
- (UIView*) getWidgetView
{
    NSLog(@"***** Entering into getWidgetView *****");
    NSLog(@"***** Exiting out of getWidgetView *****");
    return self;
}

/*
-(void)setDefaultValuesFromModel
{
    NSLog(@"***** Entering into setDefaultValuesFromModel");
    self.text = [NSString stringWithFormat:@"***** Custom Button"];
    NSLog(@"***** Exiting out of setDefaultValuesFromModel");
}
*/

// Invoked by platform when there are any updates in the end user defined properties.
-(void)modelUpdatedForProperty:(NSString *)propertyName withOldValue:(id)oValue newValue:(id)nValue
{
    NSLog(@"***** Entering into modelUpdatedForPropertywithOldValuenewValue *****");
	NSLog(@"***** PropertyName: %@ *****" ,propertyName);
	NSLog(@"***** OldValue: %@ *****" ,oValue);
	NSLog(@"***** NewValue: %@ *****" ,nValue);
    if ([propertyName isEqualToString:@"text"]) 
	{
		NSLog(@"***** Updating the value for the property %@ from %@ to %@ *****",propertyName,oValue,nValue);
        self.text = [NSString stringWithFormat:@"%@" ,nValue];
    }
    NSLog(@"***** Exiting out of modelUpdatedForPropertywithOldValuenewValue *****");
}

/*
// Start - Layout related methods
- (void) willBeginLayout
{
    NSLog(@"***** in %s",__PRETTY_FUNCTION__);
}

- (void) didEndLayout
{
    NSLog(@"***** in %s",__PRETTY_FUNCTION__);
}
// End - Layout related methods

// Start - Widget lifecycle events
- (void) didCreateWidget
{
    NSLog(@"***** in %s",__PRETTY_FUNCTION__);
}

- (void) willDestroyWidget
{
   NSLog(@"***** in %s",__PRETTY_FUNCTION__);
}
*/
-(void)dealloc
{
    NSLog(@"***** Entering into dealloc *****");
    self.text = nil;
    [super dealloc];
    NSLog(@"***** Exiting out of dealloc *****");
}
// End - Widget lifecycle events
@end