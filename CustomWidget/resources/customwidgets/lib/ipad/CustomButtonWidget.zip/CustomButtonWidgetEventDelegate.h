#import <Foundation/Foundation.h>

@protocol CustomButtonWidgetEventDelegate <NSObject>

	-(void)onClickHandler;

@end
