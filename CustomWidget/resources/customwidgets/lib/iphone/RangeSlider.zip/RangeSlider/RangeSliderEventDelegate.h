//
//  RangeSliderEventDelegate.h
//  CustomRangeSlider
//
//  Created by Rohini Kumar Barla on 05/03/13.
//  Copyright (c) 2013 Kony. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol RangeSliderEventDelegate <NSObject>

-(void)updatedMinValue:(CGFloat)minValue andMaxValue:(CGFloat)maxValue;

@end
