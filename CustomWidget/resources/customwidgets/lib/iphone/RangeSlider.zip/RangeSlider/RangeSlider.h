//
//  RangeSlider.h
//  RangeSlider
//
//  Created by Mal Curtis on 5/08/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CWIWidget.h"
#import "KonyCWIEnvironment.h"
#import "RangeSliderEventDelegate.h"

@interface RangeSlider : UIControl<CWIWidget> {
    
    // 2 lines
    KonyCWIEnvironment *konyEnviroment;
    id <RangeSliderEventDelegate> rangeSliderDelegate;
    
    float minimumValue;
    float maximumValue;
    float minimumRange;
    float selectedMinimumValue;
    float selectedMaximumValue;
    float distanceFromCenter;

    float _padding;
    
    BOOL _maxThumbOn;
    BOOL _minThumbOn;
    
    UIImageView * _minThumb;
    UIImageView * _maxThumb;
    UIImageView * _track;
    UIImageView * _trackBackground;
}

@property(nonatomic) float minimumValue;
@property(nonatomic) float maximumValue;
@property(nonatomic) float minimumRange;
@property(nonatomic) float selectedMinimumValue;
@property(nonatomic) float selectedMaximumValue;

@property(nonatomic,retain) NSString *minThumbImageName;
@property(nonatomic,retain) NSString *maxThumbImageName;
@property(nonatomic,retain) NSString *trackBackgroundImageName;
@property(nonatomic,retain) NSString *trackHighlightImageName;


// 2 lines
@property (nonatomic, retain) KonyCWIEnvironment *konyEnviroment;
@property (nonatomic, retain) id <RangeSliderEventDelegate> rangeSliderDelegate;

-(void)setDefaultValuesFromModel;
-(void)resetToDefaultValue:(float)selectedMax selectedMinValue:(float)selectedMin;
-(void)getVoid;
-(int)getInt:(int) var;
-(float)getFloat:(float) var;
-(double)getDouble:(double) var;
-(long)getLong:(long) var;
-(NSString *)getNSString:(NSString *) var;
-(NSNumber *)getNSNumber:(NSNumber *) var;
-(NSArray *)getNSArray:(NSArray *) var;
-(NSDictionary *)getNSDictionary:(NSDictionary *) var;
-(NSObject *)getNSObject:(NSObject *) var;
-(BOOL) getBool:(BOOL) var;
@end
